from scipy.sparse import data
import torch
import torch.nn as nn
import numpy as np
import scipy.sparse
import scipy.io
from sklearn.metrics import roc_auc_score
from datetime import datetime
import argparse

import networkx as nx
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

import scipy.io as sio

import torch.nn.functional as F

import math

from torch.nn.parameter import Parameter
from torch.nn.modules.module import Module
import scipy.sparse as sp


class GraphConvolution(Module):
    """
    Simple GCN layer, similar to https://arxiv.org/abs/1609.02907
    """

    def __init__(self, in_features, out_features, bias=True):
        super(GraphConvolution, self).__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = Parameter(torch.FloatTensor(in_features, out_features))
        if bias:
            self.bias = Parameter(torch.FloatTensor(out_features))
        else:
            self.register_parameter('bias', None)
        self.reset_parameters()

    def reset_parameters(self):
        stdv = 1. / math.sqrt(self.weight.size(1))
        self.weight.data.uniform_(-stdv, stdv)
        if self.bias is not None:
            self.bias.data.uniform_(-stdv, stdv)

    def forward(self, input, adj):
        support = torch.mm(input, self.weight)
        output = torch.spmm(adj, support)
        if self.bias is not None:
            return output + self.bias
        else:
            return output

    def __repr__(self):
        return self.__class__.__name__ + ' (' \
               + str(self.in_features) + ' -> ' \
               + str(self.out_features) + ')'

class Encoder(nn.Module):
    def __init__(self, nfeat, nhid, dropout):
        super(Encoder, self).__init__()

        self.gc1 = GraphConvolution(nfeat, nhid)
        self.gc2 = GraphConvolution(nhid, nhid)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = F.relu(self.gc2(x, adj))

        return x


class Attribute_Decoder(nn.Module):
    def __init__(self, nfeat, nhid, dropout):
        super(Attribute_Decoder, self).__init__()

        self.gc1 = GraphConvolution(nhid, nhid)
        self.gc2 = GraphConvolution(nhid, nfeat)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = F.relu(self.gc2(x, adj))

        return x


class Structure_Decoder(nn.Module):
    def __init__(self, nhid, dropout):
        super(Structure_Decoder, self).__init__()

        self.gc1 = GraphConvolution(nhid, nhid)
        self.dropout = dropout

    def forward(self, x, adj):
        x = F.relu(self.gc1(x, adj))
        x = F.dropout(x, self.dropout, training=self.training)
        x = x @ x.T

        return x


class Dominant(nn.Module):
    def __init__(self, feat_size, hidden_size, dropout):
        super(Dominant, self).__init__()

        self.shared_encoder = Encoder(feat_size, hidden_size, dropout)
        self.attr_decoder = Attribute_Decoder(feat_size, hidden_size, dropout)
        self.struct_decoder = Structure_Decoder(hidden_size, dropout)

    def forward(self, x, adj):
        # encode
        x = self.shared_encoder(x, adj)
        # decode feature matrix
        x_hat = self.attr_decoder(x, adj)
        # decode adjacency matrix
        struct_reconstructed = self.struct_decoder(x, adj)
        # return reconstructed matrices
        return struct_reconstructed, x_hat

def load_anomaly_detection_dataset(dataset, datadir='data'):
    data_mat = sio.loadmat('/home/z/PycharmProjects/django_platform/project/pythonProject/myweb/plat/GCN_AnomalyDetection_pytorch/data/BlogCatalog.mat')
    adj = data_mat['Network']
    feat = data_mat['Attributes']
    truth = data_mat['Label']
    truth = truth.flatten()

    adj_norm = normalize_adj(adj + sp.eye(adj.shape[0]))
    adj_norm = adj_norm.toarray()
    adj = adj + sp.eye(adj.shape[0])
    adj = adj.toarray()
    feat = feat.toarray()
    return adj_norm, feat, truth, adj


def normalize_adj(adj):
    """Symmetrically normalize adjacency matrix."""
    adj = sp.coo_matrix(adj)
    rowsum = np.array(adj.sum(1))
    d_inv_sqrt = np.power(rowsum, -0.5).flatten()
    d_inv_sqrt[np.isinf(d_inv_sqrt)] = 0.
    d_mat_inv_sqrt = sp.diags(d_inv_sqrt)
    return adj.dot(d_mat_inv_sqrt).transpose().dot(d_mat_inv_sqrt).tocoo()


def loss_func(adj, A_hat, attrs, X_hat, alpha):
    # Attribute reconstruction loss
    diff_attribute = torch.pow(X_hat - attrs, 2)
    attribute_reconstruction_errors = torch.sqrt(torch.sum(diff_attribute, 1))
    attribute_cost = torch.mean(attribute_reconstruction_errors)

    # structure reconstruction loss
    diff_structure = torch.pow(A_hat - adj, 2)
    structure_reconstruction_errors = torch.sqrt(torch.sum(diff_structure, 1))
    structure_cost = torch.mean(structure_reconstruction_errors)

    cost = alpha * attribute_reconstruction_errors + (1 - alpha) * structure_reconstruction_errors

    return cost, structure_cost, attribute_cost


def train_dominant(args):
    adj, attrs, label, adj_label = load_anomaly_detection_dataset(args.dataset)

    adj = torch.FloatTensor(adj)
    adj_label = torch.FloatTensor(adj_label)
    attrs = torch.FloatTensor(attrs)

    '''model_path = '/home/z/django_platform-main/project/pythonProject/myweb/plat/GCN_AnomalyDetection_pytorch/gcn.pt'

    GCN_model = torch.load(model_path, map_location='cpu')

    GCN_model.eval()  # 设置为评估模式'''

    gcn_path = '/home/z/PycharmProjects/django_platform/project/pythonProject/myweb/plat/GCN_AnomalyDetection_pytorch/gcn.pt'

    model = Dominant(feat_size=attrs.size(1), hidden_size=args.hidden_dim, dropout=args.dropout)
    model.load_state_dict(
        torch.load(gcn_path,
                   map_location='cpu'))
    model.eval()

    # 使用模型处理数据集
    with torch.no_grad():  # 不需要计算梯度
        A_hat, X_hat = model(attrs, adj)
        loss, struct_loss, feat_loss = loss_func(adj_label, A_hat, attrs, X_hat, args.alpha)
        score = loss.detach().cpu().numpy()

        # 计算AUC分数
    auc = roc_auc_score(label, score)

    # 计算特征重建误差
    diff_feature = torch.pow(X_hat - attrs, 2)

    feature_reconstruction_errors = torch.sqrt(torch.sum(diff_feature, dim=1))

    # 设定异常阈值（这里简单地取重建误差的中位数加上一个标准差作为阈值）
    threshold = torch.median(feature_reconstruction_errors) + torch.std(feature_reconstruction_errors)

    # 识别异常节点
    abnormal_nodes = (feature_reconstruction_errors > threshold).nonzero(as_tuple=True)[0]

    abnormal_nodes = abnormal_nodes.detach().cpu().numpy()
    return abnormal_nodes


if __name__ == '__main__':

    dataset_name = 'BlogCatalog'
    hidden_dim = 64
    epoch = 100
    lr = 5e-3
    dropout = 0.3
    alpha = 0.8
    device = 'cpu'

    fake_args = argparse.Namespace(
        dataset=dataset_name,
        hidden_dim=hidden_dim,
        epoch=epoch,
        lr=lr,
        dropout=dropout,
        alpha=alpha,
        device=device
    )

    train_dominant(fake_args)
    #print('1')